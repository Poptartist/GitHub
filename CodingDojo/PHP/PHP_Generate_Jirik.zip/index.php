<html>
<head>
	<title></title>
			<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="main.css.php">
	<script src= 'http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js'></script>
		<script type="text/javascript" src ="main.js.php">
		</script>
</head>
<body>
	<h1>Heading 1</h1>
	<p>I had no idea you could use PHP to create a CSS file or any other files than html!!!</p>

</body>
</html>