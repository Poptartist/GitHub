<?php
 header('Content-type: text/css');
 $array = array ("blue", "red", "green", "yellow", "navy", "maroon");
 $n = rand(0, 5);
 $m = rand(0, 5);
?>

h1 {
	color: <?php echo $array[$n]; ?>
}

p {
	color: <?php echo $array[$m]; ?>
}


